#include<iostram>
#include<cstring>

class Laptop()
{
	int lid;
	char *make;
	double cost;
public:
	Laptop();
	Laptop(int ,char*,double);
	void show();
	~Laptop();
}

Laptop::~Laptop()
{
	delete[]make;
}
Laptop::



int main()
{





	return 0;
}
