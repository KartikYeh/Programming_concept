#include<iostream>
#include<cstring>
using namespace std;

class Laptop
{
	int lid;
	char *make;
	double cost;
public :
	Laptop();
	~Laptop();
	void show();
	Laptop(Laptop &); 
	Laptop(int, char*, double);
	
};
Laptop::~Laptop()
{
	delete []make;
}
Laptop::Laptop(Laptop &l)
{
	lid=l.lid;
	make=new char[strlen(l.make)+1];
	strcpy(make,l.make);
	cost=l.cost;
}
Laptop::Laptop()
{
	lid=10;
	make =new char[3];
	strcpy(make,"hp");
	cost=4500;
}
Laptop::Laptop(int id, char *m, double c)
{
	lid=id;
	make=new char[strlen(m)+1];
	strcpy(make,m);
	cost=c;
}
void Laptop::show()
{
	cout<<lid<<endl;
	cout<<make<<endl;
	cout<<cost<<endl;
	
}

int main()
{	
	Laptop l1;
	Laptop l2(100,"Lenovo",45000);
	l1.show();
	cout<<endl;
	Laptop l4(l2);
	l4.show();		
	
	return 0;
}

