#include<iostream>
using namespace std;

int  Add(int a,int b,int c=0,int d=0,int e=0,int f=0)
{

	return a+b+c+d+e+f;

}

int main()
{
	cout<<12+13+14+16+17+18<<endl;
	cout<<12+13+14+16+17<<endl;
	cout<<12+13+14+16<<endl;
	cout<<12+13+14<<endl;
	cout<<12+13<<endl;




	return 0;
}
