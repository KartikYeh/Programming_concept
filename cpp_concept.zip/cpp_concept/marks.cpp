#include<iostream>
using namespace std;






int main(){
	int n;
	
	cout<<"Enter size of array"<<endl;
	cin>>n;
	
	int *p= new int[n];
	
	for(int i=0;i<n;i++)
	{	cout<<"enter the marks:"<<endl;
		cin>>p[i];
	}
		
	for(int i=0;i<n;i++)
	{
		cout<<" "<<p[i]<<" ";
	}
	delete []p;
	






	return 0;
}
