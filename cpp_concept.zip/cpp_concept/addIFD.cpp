#include<iostream>
using namespace std;

int Add(int a,int b)
{
	return a+b;
	
}
float Add(float a,float b)
{
	return a+b;
	
	
}
double Add(double a,double b)
{
	return a+b;
	
	
}

int main()
{
	
	
	cout<<""<<Add(20,20)<<endl;
	cout<<""<<Add(4.22f,6.66f)<<endl;
	cout<<" "<<Add(44.55f,33.44f)<<endl;




	return 0;
}
