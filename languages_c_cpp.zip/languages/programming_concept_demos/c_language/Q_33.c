
#include <stdio.h>

 
typedef struct books
{
	int bookid;
	char title[20];
	double price;
} bk; 

void display(bk b1[5])
{  
	for(int i=0;i<5;i++)
	{
		
		printf("the id,title,price is%d %s %lf \n",b1[i].bookid,b1[i].title,b1[i].price);
	}
	
};
	

 
int main ()
{	bk b[5];
	for(int i=0;i<5;i++)
	{
		printf("Enter the id,title,price\n");
		scanf("%d %s %lf",&b[i].bookid,&b[i].title,&b[i].price);
	}
	display(b);
	
	
return 0;
}
