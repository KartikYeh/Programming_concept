#include<stdio.h>


void areacircum();
void areaperi();

int main(){

	prin



	return 0;
}
