#include <stdio.h>

int main(){
  int m,U,C;
  
  m=21;
  while(1){
  
 
  printf("the total match sticks is:%d\n",m);
  printf("select the sticks between 1,2,3,4:\n");
  scanf("%d",&U);
  if(U <= 0 || U > 4){
    printf("Please enter value between 1 and 4 including...\n");
    continue;
    }
  m-=U;
  
  C = 5 - U;
  printf("match sticks select by computer:%d\n",C);
  m-=C;
  
  
  
  
  
  if(m==1){
printf("total sticks left:%d\n",m);
    printf("you lost the game\n");
    break;

    }
  
  }
  
  



}
