#include<stdio.h>
void acceptM(int matrix1[3][3])
{
	int i, j;

	for(i=0; i<3; i++)
	{
		for(j=0; j<3; j++)
		{
			scanf("%d", &matrix[i][j]);
		}
	}
}

void displayM(int matrix1[3][3] )
{
	for(int i=0; i<3; i++)
	{
		for(int j=0; j<3; j++)
		{
			printf("%d ", matrix[i][j]);
		}
		printf("\n");
	}
}
void transpose(int M[3][3], T[3][3])
{
	for(int i=0; i<3; i++)
	{
		for(int j=0; j<3; j++)
		{
			T[j][i]=M[i][j];
		}
	}
}
int main()
{
	int M1[3][3], M2[3][3];
	printf("Enter the matrix1 : \n");
	acceptM(M1);
	printf("You entered matrix\n");
	displayM(M1);
	printf("Enter the matrix2 : \n");
	accept(M2);
	printf("You entered matrix \n");
	displayM(M2);
	
}
