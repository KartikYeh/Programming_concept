#include<stdio.h>
#include<math.h>


int fact(int n)
{
	int f=1;
	while(n>0)
	{
		f=f*n;
		n--;
	}
	return f;
}

 float power(float base , int index)
{
	int i;
	float p=1.0f;
	for(i=0; i<index; i++)
	{
		p=p*base;
	}
	return p;
} 




int main(){


	
	
	printf("%d",fact(5));
	printf("%f",power(2,4));



	return 0;
}

