#include<stdio.h>
int main()
{
	int a, b;
	char ch;
	printf("Enter two numbers for operation\n");
	scanf("%d%d", a, b);
	printf("Enter the ")
}
