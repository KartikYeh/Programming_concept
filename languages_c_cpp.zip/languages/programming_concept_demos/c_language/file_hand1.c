#include<stdio.h>
#include<string.h>
int main()
{
	char s[50];
	FILE *fp = fopen("abc.txt","a");
	
	while(1)
	{
		gets(s);
		if(strlen(s)==0)
			break;
		fputs(s,fp);
		
		fputc('\n',fp);
	}
	fclose(fp);
	return 0;
}
