#include<stdio.h>
//fopen, fclose, fgetc, fgets, fputc,fputs
//EOF = End of file => 26 is ascii value
int main()
{	
	char ch;
	FILE *fp;
	fp = fopen("abc.txt","r"); //r,w,a,r+,w+,a+
	while(1)
	{
		ch = fgetc(fp);
		if (ch == EOF)
			break;
		printf("%c",ch);
	}
	fclose(fp);
	return 0;
}
