#include<stdio.h>

int main()
{
	int m=21,u,c;
	printf("sticks =%d \n",m);
	
	
	
	while(1){
	
	
		printf("Enter the choice between 1,2,3,&4 = \n");

		scanf("%d",&u);
		if(u>1 && u<5){
		
		
		m-=u;
		
		printf("Remaining Sticks is =%d \n",m);
		
		c=5-u;
		
		
		
		printf("the choice of computer = %d \n",c);
		
		m = m-c;
		printf("remaning is = %d \n",m);
		
		
		
		
		if(m==1){
			printf("You lost the game\n");
			break;
		}
	}else
		printf("Invalid choice");
	}






	return 0;
}
