#include<iostream>

#include<cstring>

using namespace std;

int main()
{	string str;
	cout<<"enter string"<<endl;
	getline(cin,str);
	cout<<str<<endl;
	
	
	
	return 0;
}
