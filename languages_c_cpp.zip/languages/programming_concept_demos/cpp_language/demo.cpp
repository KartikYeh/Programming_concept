#include<iostream>
using namespace std;
int main()
{
	int a,b;
	float f;
	cout<<"Hello cpp"<<endl;
	cout<<"Enter two numbers :- "<<endl;
	cin>>a>>b;
	int c=a+b;
	cout<<"Sum is "<<c<<endl;
	cout<<"Enter float :"<<endl;
	cin>>f;
	cout<<f<<endl;
	return 0; 
}
