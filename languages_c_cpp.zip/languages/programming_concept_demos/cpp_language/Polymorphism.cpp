#include<iostream>
using namespace std;

/*	pure virtual functioon - it is virtual function initialized to zero and  do not have any
	definition 
	
	abstract class - 1.it is a class which is  having at least one pure virtual declear 
	inside it.
	2. we can not create an object of an abstract class.
	3. if a class  is inheriting abstract classs then , it is compalsary for that class
	  to override pure virtual function of the base class (abstract class).
	  
	pure abstract class - 1.it is class having all function decleared as pure virtual.
	 
	
	
	
	
	
	
		
*/

class polygon{

public:
	virtual double calcarea()=0;
	virtual double calcperi()=0;

	
	

};

class circle:public polygon{
        int radius;
public:
        circle();
        circle(int);
        double calcarea();
        double calcperi();
};
circle::circle()
{
        radius=1;
}
circle::circle(int r)
{
        radius=r;
}
 double circle::calcarea()
 {
         return 3.142f*radius*radius;
 }
 double circle::calcperi()
 {
        return 2*3.142f*radius;     
 }
 class rectangle:public polygon
 {
        int len;
        int brd;
public: 
        rectangle();
        rectangle(int,int);
        double calcarea();
        double calcperi();
 };
 rectangle::rectangle()
 {
        len=brd=2;
 }
 rectangle::rectangle(int l, int b)
 {
        len=l;
        brd=b;
 }
 double rectangle::calcarea()
 {
      	return len*brd;  
 }
  double rectangle::calcperi()
 {
      	return 2*(len+brd);  
 }
 class square:public rectangle
 {
       
 public: 
        square();
        square(int);
        double calcarea();
        double calcperi();
 };
 
  square::square()
  {}
  
square::square(int s):rectangle(s,s){
  	}
  
  double square::calcarea()
 {
 	return rectangle::calcarea();
 }
 double square::calcperi()
 {
 	return rectangle::calcperi();
 }
 
 
 int main()
 {
 	rectangle r1(2,3);
 	polygon*ptr=&r1;
 	cout<<ptr->calcarea()<<endl;
 	return 0;
 
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
