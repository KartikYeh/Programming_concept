#include<iostream>
#include<cstring>

using namespace std;


class myexception
{
	int line;
	char function[50];
	char file[50];
public :
	myexception();
	myexception(int ,const char*,const char*);
	void show();
		
};

myexception::myexception()
{
	
}
myexception::myexception(int l ,const char*fn,const char*fl)
{
	line= l;
	strcpy(function,fn);
	strcpy(file,fl);
}
void myexception::show()
{
	cout<<"line number-"<<line<<endl;
	cout<<"function namer-"<<function<<endl;
	cout<<"file name-"<<file<<endl;
}


double  divide (int num , int den  )

{
	
	if (den ==0 )
		throw myexception(__LINE__,__FUNCTION__,__FILE__);
	return (double)num/den;
}
int main()
{

	try
	{
	cout<<divide(12,0)<<endl;
	}
	catch(myexception e)
	{
		e.show();
	}


	return 0;
}
