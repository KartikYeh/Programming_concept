#include<iostream>
using namespace std;

class Employee
{
      int emp_id;
      char emp_name[20];
      double salary;
public:
      Employee();
      int grtId();
      Employee(int,char*,double);
      void Accept();
      void display();
};
int Employee::getId()
{
      return emp_id;
}
Employee::Employee()
{
}

Employee::Employee(int id,char *n, double s)
{
      emp_id=id;
      strcpy(emp_name,n);
      salary=s;
}
void Employee::Accept()
{
      cout<<"Enter info(id ,name,salary)"<<endl;
      cin>>emp_id>>emp_name>>salary;
}
void Employee::Display()
{
      cout<<emp_emp_id<<" "<<emp_name<<" "<<salary<<endl; 

}

int main(){
    
    int choice,cnt=0,empid;
    Employee e[10];
    
    while(true)
    {
            cout<<"1.Insert Employee"<<endl;
            cout<<"2.Update Employee"<<endl;
            cout<<"3.Display"<<endl;
            cout<<"4.Exit"<<endl;
            cin>>choice;
            switch(choice)
            {
                    case 1:
                            e[cnt++].Accept();
                            break;
                    case 2:
                            cout<<"1.Enter empid to be updated"<<endl;
                            cout<<"2.Enter empid to be updated"<<endl;
                            cout<<"3.Enter empid to be updated"<<endl;
                            cout<<"4.exit"<<endl;
                    case 3:
                    case 4:
            }
            
    
    
    
    
    }









     return 0;
}
