#include<iostream>
#include<list>

using namespace std;

int main()
{

	list<int> l1;
	
	
	
	
	//cout<<l1.size()<<""<<l1.capacity()<<endl; 
	
	l1.push_back(15);
	l1.push_back(30);
	l1.push_back(40);
	l1.push_back(50);
	l1.push_front(60);
	
	
	
	list<int>::iterator itr;  //syntax acccess element of list
	for(itr=l1.begin();itr!=l1.end();itr++)
	{
		cout<<*itr<<" ";
	}
	
	cout<<endl;
	
	
	
	
	
	

	return 0;
}
