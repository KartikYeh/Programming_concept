#include<iostream>
using namespace std;



template<typename T>  // function with sigle template argument
void swap(T a, T b)
{
	T temp;
	temp=a;
	a=b;
	b=temp;
	
	cout<<a<<" "<<b<<endl;
	

}
template<typename T,typename U> // function with multiple template argument
 T add(T a, U b)
{
	return a+b;
	
	cout<<a<<" "<<b<<endl;
	

}


int main()
{
	swap(12,24);
	swap("narayane","kartik");
	swap(3.4f,1.1f);
	cout<<add(2.1f,2)<<endl;

	return 0;
}
