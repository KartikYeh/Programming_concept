#include<iostream>
using namespace std;
class complex
{
	int real;
	int img;
public:
	complex();
	complex(int , int);
	int getreal();
	void setreal(int);
	int getimg();
	void setimg(int);
	void display(){
		cout<<"real="<<real<<endl;
		cout<<"img="<<img<<endl;	
	}
};

complex::complex()
{
	real=22;
	img=12;
}
complex::complex(int a , int b)
{
	real=a;
	img=b;
}
int complex::getreal()
{
	return real;
}
void complex::setreal(int a)
{
	 real=a;
}
int complex::getimg()
{
	return real;
}
void complex::setimg(int b)
{
	 real=b;
}
/*void complex::display()
{  
	cout<<"real="<<real<<endl;
	cout<<"img="<<img<<endl;

}
*/

int main()
{	complex a2;
	a2.display();
	
	complex a1(22,33);
	a1.display();
	a1.setreal(12);
	a1.setimg(13);
	a1.display();

	return 0;
}






