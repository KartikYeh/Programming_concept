#include<iostream>
using namespace std;

/*
	Ecxception - ti is run time anotomy, try ,catch and throw
	
*/


class A
{

};

double  divide (int num , int den  )

{
	A obj ;
	if (den ==0 )
		throw 'x';
	return (double)num/den;
}

int main()

{
	try
	{
		cout<<divide(10,0)<<endl;
		
	}
	catch(int a)
	{
		cout<<"int-denominator is zero"<<endl;
	}
	catch(char const *b)
	{
		cout<<"char*-denoinator is zero"<<b<<endl;
	}
	catch(double d)
	{
		cout<<"double -denominator is zero"<<endl;
	}
	catch(A obj)
	{
		cout<<"a-denominator is zero"<<endl;
	}
	catch (...)//elipse
	{
		cout<<"universal catch - denominator is zero"<<endl;
	}


	return 0;
}














































