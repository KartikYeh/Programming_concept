#include<iostream>
#include<vector>
using namespace std;
int main()
{
	int a;
	vector<int> v1;
	
	
	cout<<"enter the values"<<endl;
	for(int i=0; i<6;i++){
		cin>>a;
		v1.push_back(a);
	}
	
	for(int i=0; i<6;i++){
		
		cout<<v1[i]<<" ";
	}
	
	cout<<"enter the two more values"<<endl;
	for(int i=0; i<2;i++){
		cin>>a;
		v1.push_back(a);
	}
	for(int i=0; i<v1.size();i++){
		
		cout<<v1[i]<<" ";
	}
	cout<<"pop two more values"<<endl;
	for(int i=v1.size(); i<2;i++){
		cin>>a;
		v1.pop_back();
	}
	for(int i=0; i<6;i++){
		
		cout<<v1[i]<<" ";
	}
	
	



	return 0;
}
