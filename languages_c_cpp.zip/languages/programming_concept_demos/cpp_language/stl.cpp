#include <iostream>
#include<vector>
using namespace std;
/*
	STL -standard template library
		
		1.containers:
			a.sequence contain e.g vector ,list, deque
			b.associator container e.g set ,multiset, map,multimap
			c.container adapters e.g stack ,queue
			
		2.Iterator: input ,output, forward, bi-directional,random access iterators
		3.Algorithms- min ,max,min_element,max_ellement,accumulate,sort
		4.Functions Objecs- these are objects of classes for which(),operator is overloaded
*/
class A
{
public:
	class B
	{
	
	};
};

int main()
{



	A::B obj;
	vector<int> v1;
	
	
	
	
	//cout<<v1.size()<<""<<v1.capacity()<<endl; 
	
	v1.push_back(15);
	v1.push_back(30);
	v1.push_back(40);
	v1.push_back(50);
	v1.push_back(60);
	
	for(int i=0;i<v1.size();i++)
	{
		cout<<v1[i]<<" ";  //syntax acccess element .... only with vector
	}
	cout<<endl;
	
	vector<int>::iterator itr;  //syntax acccess element of vector
	for(itr=v1.begin();itr!=v1.end();itr++)
	{
		cout<<*itr<<" ";
	}
	
	cout<<endl;
	
	
	
	
	
	

	return 0;
}




























