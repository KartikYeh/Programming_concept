#include<iostream>
#include"wageEmployee.h"
using namespace std;            

WageEmployee::WageEmployee()
{
        hours=0;
        rate=0;
}

WageEmployee::WageEmployee(int id, char* n,int d,int m,int y,int h,int r):Employee(id,n,d,m,y)
{
        hours=h;
        rate=r;
}
void WageEmployee::Display()
{
        Employee::Display();
        cout<<"hours="<<hours<<endl;
        cout<<"rate="<<rate<<endl;
}
int WageEmployee::calcsalary()
{
        return hours*rate;    
}
