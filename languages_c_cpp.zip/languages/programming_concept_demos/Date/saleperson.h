#include"wageEmployee.h"

class saleperson:public WageEmployee
{
   int sales;
   int comm;
public:
    saleperson(); 
    saleperson(int, char*,int,int,int,int,int,int,int);
    void Display();
    int calcsalary();

};  
