#include<iostream>
#include "saleperson.h"
using namespace std;

/*
          function overloding - multiple function with same name, same signature and same return type defined in different scope of classes of hierarchy of inheritance is called  function overriding
          object slicing  - whenever a derived class object is assigned to base class object the attributes which are specific to derived class object are sliced off from  that object .this is   
          called object slicing 
          
          in c++ , base class pointer can hold the address of derived class object but . derived class pointer can not hold the address of base class object . i.e only upcasting is posilble 
          
          Binding - it is an association of function call to the corresponding function definition .
              
              w/o virtual fns - Static Binding , Compile Time Binding, Early binding
              with virtual fns - Dynamic binding , Run time Binding , Late binding
          
          Polymorphism - It is different response given by object to a same command. In C++, polymorphism
              is implemented using virtual function.
          
          */


int main()
{	
	saleperson Wel(10,"kar",20,20,2001,2,5,10,2);
	Wel.Display();
	cout<<"sales person salary is "<<Wel.calcsalary()<<endl;






	return 0;
}
