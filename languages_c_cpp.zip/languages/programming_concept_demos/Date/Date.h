


class Date
{
	int dd,mm,yy;
public:
	void display();
	Date(int ,int ,int );
	Date();
	
};
