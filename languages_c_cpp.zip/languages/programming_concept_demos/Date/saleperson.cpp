#include<iostream>
#include"saleperson.h"
using namespace std;

saleperson::saleperson()
{
    sales=0;
    comm=0;
}
    
saleperson::saleperson(int id, char* n,int d,int m,int y,int h,int r,int s,int c):WageEmployee(id,n,d,m,y,h,r)
{
    sales=s;
    comm=c;
}
void saleperson::Display()
{
    WageEmployee::Display();
    cout<<" "<<sales<<endl;
    cout<<" "<<comm<<endl;
    cout<<"wegemployees salary is : " <<WageEmployee::calcsalary()<<endl;
}
int saleperson::calcsalary()
{
    return WageEmployee::calcsalary()+sales*comm;
}
    


