<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action = "calculateinterest.php">
        Enter the Amount:<input type="text" name="amt" id = "amt"><br>
        Rate of Intrest:<input type="text" name="rat" id = "rat"><br>
        Number of Years:<input type="text" name="yr" id = "yr"><br>
        <button type = "submit" name = "btn">Submit</button>
        
    </form>
    
</body>
</html>