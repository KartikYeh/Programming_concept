<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <h1>Hello World!</h1>
        <?php
        echo "<h2>welcome to php programming</h2>";
        $a=34;
        $b=50;
        echo "Addition is: ".($a+$b);
        ?>
</body>
</html>
