
<html>
<head>
    
</head>
<body>
    <?php
    
    function showtable($num){
        for($i=1;$i<=10;$i++)
        {
            echo "$num * $i = ".($i*$num)."<br>";
        }
        echo "<hr>";
    }
    function factorial($num){
        $b=1;
        for($i=$num;$i>0;$i--)
        {
           $b = ($i*$b);
        }
        echo "factorial of ".$num." is :".$b."<br>";
    }
     $a=$_GET['n1'];
     $b=$_GET['n2'];
     $btn=$_GET['btn'];

     echo "first value is  :".$a."<br>";
     echo "second value is :".$b."<br>";
     echo "btn:".$btn."<br>";   
    switch($btn){

        case "add":
            echo "Addition is: ".($a+$b)."<br>";
            break;
        case "sub":
            echo "Substraction is: ".($a-$b)."<br>";
            break;
        case "mul":
            echo "Multiplication is: ".($a*$b)."<br>";
            break;
        case "div":
            echo "Divison is: ".($a/$b)."<br>";
            break;
        case "table":
            showtable($a);
            showtable($b);
            break;           
        case "fact":
            factorial($a);
            factorial($b);
            break;
    }
    echo "Job Done";
  ?> 
    
   
</body>
</html>