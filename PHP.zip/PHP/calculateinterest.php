<?php

    $a=$_GET['amt'];
    $b=$_GET['rat'];
    $c=$_GET['yr'];
    $e=($a*($b/100))*$c;
    $f=$a+$e;

    echo "principal amount is: $a<br>";
    echo "rate of intrest is: $b %<br>";
    echo "Term is: $c years<br>";
    echo "Total Intrest:$e<br>";
    echo "Total Amount:$f<br>";


?>