<?php
    $car = array("bmw"=>80,"I10"=>10,"civic"=>40);
    foreach($car as $k=>$v)
    {
        echo "$k----->$v<br>";
    }


?>