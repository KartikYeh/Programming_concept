<?php
function addword($wrd){
    $fp=fopen("find.txt","a");
    fwrite($fp,"\n$wrd");
    fclose($fp);
}
$wrd="sumedh";
#$wrd=_REQUEST["wrd"];
$arr=file("find.txt");

print_r($arr);//arry print with variable name
$flag=false;
#check whether word exist in the file

foreach($arr as $w){
    echo strlen($w);
    echo "$w-->$wrd<br>";
    if(trim($w)==$wrd){
        echo "word exists";
        $flag=true;
        break;
    }
}
if(!flag){
    echo "word not found ";
    addword($wrd); 
}

?>