<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
</head>
<body>
    <form action = "formcalc.php" method = "get">
        Number1 = <input type="text" name="n1" id = "n1"><br> 
        Number2 = <input type="text" name="n2" id = "n2"><br>
        <button type="submit" name="btn" value="add">Addition</button>
        <button type="submit" name="btn" value="sub">Substraction</button>
        <button type="submit" name="btn" value="mul">Multiplication</button>
        <button type="submit" name="btn" value="div">Division</button>
        <button type="submit" name="btn" value="table">show table</table></button>
        <button type="submit" name="btn" value="fact">fact</button>
        <button type="reset" name="btn" >clear</button>
    </form>
</body>
</html>