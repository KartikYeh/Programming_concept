<?php
    $car = array("volvo","porche","mustang","bmw");
    $cnm= $_GET["cname"];
    echo "you entered: ".$_GET["cname"]."<br>";
    echo "you entered: ".$_REQUEST['cname']."<br>";
    $flag=1;

    foreach($car as $val )
    {
        if($val==$cnm){
            $flag=0;
            echo "<h3>Car Found</h3>";
            break;
        }
    }
    if($flag==1){
        echo "Car not found and added sucessfully <br>";
        array_push($car,$cnm);
    }
    for($i=0;$i<count($car);$i++)
    {
        echo $car[i]."<br>";
    }
?>