<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
        session_start();
        if($_REQUEST['btn']=="finish"){
            session_unset();
            session_destroy();
            echo "session destroyed";
        }else{  
        $data = array("kartik"=>123,"rohan"=>456,"gondya"=>789);
        $a=$_REQUEST['usr'];
        $b=$_REQUEST['psw'];
        //$btn=$_REQUEST['btn'];

        if(isset($data[$a])){
            if($data[$a]==$b){
                echo "<h3>welcome $a</h3>";
                include "searchproduct.php";
            }
            else{
                echo "invalid  Password";
                include "login.php";
            }
        }else{
            echo "invalid user";
            include "login.php";
        }  
    }?> 
</body>
</html>
