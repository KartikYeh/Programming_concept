<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action = "validate.php" method = "post">
        Username = <input type="text" name="usr" id = "usr"><br> 
        Passward = <input type="password" name="psw" id = "psw"><br>
        <button type="submit" name="btn" >Submit</button>
        <button type="reset" name="btn" >clear</button>
        <button type = "submit" name = "btn" value="finish">Finish Session</button>
        
    </form>
</body>
</html>
