<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action = "cardata.php" method = "get">
    Car name: <input type = "text" name = "cname" id = "cname"><br>
    <button type = "submit" name = "btn" id = "btn">Find car</button>  
</form>  
</body>
</html>
