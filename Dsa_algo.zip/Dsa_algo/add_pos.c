#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct node 
{
	int data;
	struct node *next;	
};
void addatpos(struct node **phead,int pos,int val)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	struct node *trav=*phead;
	while(pos>2)
	{
		trav=trav->next;
		pos--;
	}
	temp->next=trav->next;
	trav->next=temp;
	
	
}
void addatend(struct node **phead,int val)
{
	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	trav=*phead;
	if((*phead)==NULL)
	{
		*phead=temp;
	}
	else
	{
		
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=temp;
	}
}
void addatbegin(struct node **phead,int val)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	
	temp=*phead;
	if((*phead)==NULL)
	{
		*phead=temp;
	}
	else
	{
		*phead)->next=temp;
		*phead=temp; 
	}
}




void display(struct node *head)
{
	struct node *trav=head;
	while(trav!=NULL)
	{
		printf("%d ",trav->data);
		trav=trav->next;
	}
	printf("\n");

}


int main()

{	int pos;
	struct node *head=NULL;
	
	addatend(&head,11);
	addatend(&head,12);
	addatend(&head,3);
	addatend(&head,15);
	
	display(head);
	
	
	printf("add position to be inserted \n ");
	scanf("%d",&pos);
	
	addatpos(&head,pos,500);
	display(head);
	addatbegin(&head,21);
	display(head);

	return 0;
}












