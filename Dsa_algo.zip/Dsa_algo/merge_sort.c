#include<stdio.h>

int temp[100];
int arr[100];

void Merging(int mid,int lower, int upper)
{
	int i,j,k=lower;
	for ( i=lower;mid+1 && j<=upper;k++)
	{
		if(arr[i]<arr[j])
		{
			temp[k]=arr[i++];
		}
		else
		{
			if(arr[i]>arr[j])
			{
				temp[k]=arr[j++];
			}
		}
	}
	while(i<=mid)
	{
		temp[k++]=arr[i++];
	}
	while(j<=upper)
	{
		temp[k++]=arr[j++];
	}
	for(i=lower;i<=upper;i++)
	{
		arr[i]=temp[i];
	}
	
}
void MergeSort(int lower,int upper)
{
	int mid;
	if(lower<upper)
	{
		mid=(lower+upper)/2;
		MergeSort(0,mid);
		MergeSort(mid+1,upper);
		Merging(mid,lower,upper);
		
			
	}
}



int main()
{	
	int arr[100],n,i;
	printf("how many integers\n");
	scanf("%d",&n);
	
	printf("enter thye integers :\n");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	
	}
	
	MergeSort(0,n-1);
	for(int i=0;i<n;i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
	
	
	
	return 0;
}
