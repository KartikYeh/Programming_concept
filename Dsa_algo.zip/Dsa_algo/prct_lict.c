#include<stdio.h>
#include<stdlib.h>

struct node 
{
	int data;
	struct node *next;
};

void Addatbegin(struct node* *head,int val)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	temp=*head;
	temp->next=*head;
	*head=temp;

}
void addatend(struct node **head,int val)
{
	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	
	temp->data=val;
	temp->next=NULL;
	
	
	if(*head==NULL)
	{
		*head=temp;
		
	}
	trav=*head;
	else
	{
		trav->next=temp;
		*head=temp;
	}
	
}
void display(struct node *head)
{
	struct node *trav=head;
	while(trav!=NULL){
	printf("%d ",trav->data);
	trav=trav->next;
	}
	
}


int main()
{
	struct node *head=NULL;
	
	Addatbegin(&head,34);
	Addatbegin(&head,40);
	Addatbegin(&head,50);
	Addatbegin(&head,44);
	
	display(head);
	
	addatend(&head,66);
	display(head);	
	

	return 0;
}
