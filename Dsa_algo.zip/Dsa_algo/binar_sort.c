#include<stdio.h>


void SelectionSort(int *arr,int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(arr[i]>arr[j])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	printf("Array after sorting\n ");
	for(i=0;i<n;i++)
	{
		printf("%d ",arr[i]);
	}
}


int BinarySearch(int *arr,int n,int val)
{
	int lower, upper , mid, index;
	lower=0;
	upper=n-1;
	
	while(lower<=upper)
	{
		mid=(lower+upper)/2;
		if(arr[mid]==val)
		{
			index=mid;
			break;
		}
		else if(arr[mid]>val)
		{
			upper=mid-1;
		}
		else if(arr[mid]<val)
		{
			lower=mid+1;
		}
	}
	return index;
}

int main()
{
	int arr[100],n,i,val,index;
	
	printf("How many integers?\n");
	scanf("%d",&n);
	
	
	printf("Enter integers:\n");
	for(i=0;i<n;i++)
	{
	
	scanf("%d",&arr[i]);
	}
	
	
	printf("Enter the element to be searched:");
	scanf("%d",&val);
	
	SelectionSort(arr,n);
	index= BinarySearch(arr,n,val);
	
	if(index!=1)
	{
		printf("Element found at index %d ",index);
		
	}
	else
	{
		printf("Element Not found\n");
	}


return 0;
}

