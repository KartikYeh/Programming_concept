 #include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct student
{
	int rollno;
	char name[20];
	double marks;
	struct student *next;//self refrence pointer
};


int main()
{
	struct student *p=(struct student*)malloc(sizeof(struct student ));
	
	p->rollno=109;
	strcpy(p->name,"kartik");
	p->marks=99;
	
	p->next=(struct student*)malloc(sizeof(struct student ));
	p->next->rollno=1088;
	strcpy(p->next->name,"rohan");
	p->next->marks=99;
	p->next->next=NULL;
	
	printf("%d\t%s\t%lf\t\n",p->rollno,p->name,p->marks);
	printf("%d\t%s\t%lf\t\n",p->next->rollno,p->next->name,p->next->marks);
	



	return 0;
}
