#include<stdio.h>

struct queue
{
	int size;
	int arr[50];
	int rear,front;
};

void Init(struct queue *q)
{
	q->size=10;
	q->rear=q->front=-1;
}
void Insert(struct queue *q,int val)
{	
	if(!isfull(q))
	{
	(q->rear)++;
	
	q->arr[q->rear]=val;
	}
	else 
		printf("queue is full");
}

int Remove(struct queue *q)
{
	int temp=-1;
	if(!isempty(q))
	
	{
	(q->front)++;
	
	temp=q->arr[q->front];
	}
	else {	q->rear=q->front-1;
		printf("queue is empty");
	}
	return temp;
}
int isfull(struct queue *q)
{
	if(q->rear == (q->size)-1)
		return 1;
	else 
		return 0;
}
int isempty(struct queue *q)
{
	if(q->rear == q->front)
		return 1;
	else 
		return 0;
}




int main()
{
	struct queue q1;
	Init(&q1);
	Insert(&q1,10);
	Insert(&q1,20);
	Insert(&q1,30);
	Insert(&q1,40);
	
	printf("%d ",Remove(&q1));
	printf("%d ",Remove(&q1));
	printf("%d ",Remove(&q1));
	printf("%d ",Remove(&q1));
	printf("\n");

	return 0;
}
