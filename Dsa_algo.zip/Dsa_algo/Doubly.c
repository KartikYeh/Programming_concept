/*
Assignment-
	Implement doubly inked list with below functionalities.
	a.AddatEnd
	b.AddatBegin
	c.AddatPosition
	d.RemoveFromEnd
	e.RemoveFromBegin;
	f.RemoveFromPsition;
*/

#include<stdio.h>
#include<stdlib.h>


struct node
{
	int data;
	struct node *prev,*next;
};

void addatend(struct node **head,int val)
{
	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	
	if((*head)==NULL)
	{
		*head=temp;
	}
	else
	{
		trav=*phead;
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=temp;
	}
}
void addatbegin(struct node **head,int val);
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->prev=NULL;
	temp->next=NULL;
	
	temp=*head;
	if(*head==NULL);
	{
		*head=temp;
	}
	else{
	while (temp->next!=NULL)
	{
		temp->next=*head->prev;
		temp=*head;
	}
	}
	
	

} 
void Addatpos(struct node **head,int val,int pos)
{	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->prev=NULL;
	temp->next=NULL;
	trav=*head;
	if(*head==NULL)
	{
		*head=temp;
	}
	else
	{
		while(pos>2)
		{
			trav=trav->next;
			pos--;	
		}
		temp->next=trav->next;
		trav->next->prev=temp;
		temp->prev=trav;
		trav->next=temp;
	}
	
	
}
void display(struct node *head)
{
	struct node *trav=head;
	while(trav!=NULL){
	printf("%d \n",trav->data);
	trav=trav->next;
	}
	
}





int main()
{

	struct node *head=NULL;
	int pos;

	addatend(&head,99);
	addatend(&head,11);
	addatend(&head,46);
	addatend(&head,9);
	display(head);
		
	
	printf("enter the pos");
	scanf("%d",&pos);
	
	

	
	
	Addatpos(&head,55,3);
	display(head);





	return 0;
}
