#include<stdio.h>
#include<stdlib.h>


struct node
{
	int data;
	
	struct node *next;
};

void addatend(struct node **phead,int val)
{
	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	
	if((*phead)==NULL)
		*phead=temp;
	else
	{	trav=*phead;
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=temp;
	}
	
}
void addatfront(struct node **phead,int val)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	
	if(*phead==NULL)
	{
		*phead=temp;
	
	}
	else
	{
		temp->next=*phead;
		*phead=temp;
	}
	
}
void removefront(struct node **phead)
{
	
	struct node *temp;
	if((*phead)==NULL)
	{
		printf("link list is already empty");	
	}
	else
	{	temp=*phead;
		(*phead)->next=temp;
		*phead=temp;
		free(temp);
		
	}
} 
/*void removeatpos(struct node **phead,int pos)
{	struct node *temp;
	if(*phead==NULL)
	{
		printf("link list is already empty");
	}
	else
	{
		while(pos>2)
		{
			temp=(*phead)->next;
			*phead=temp;
		}
	}

}*/
void removefromend(struct node **phead)
{
	struct node *temp;
	
	if(*phead!=NULL)
	{
		*phead=temp;	
	}else
	printf("link list is already epty");

}




void display(struct node *head)
{
	struct node *trav=head;
	
	while(trav!=NULL)
	{
	
	printf("%d ",trav->data);
	trav=trav->next;
	}
	printf("\n");
}


int main()
{
	struct node *head=NULL;
	int pos;
	
	  
	addatend(&head,10);
	addatend(&head,23);
	addatend(&head,21);
	addatend(&head,36);
	addatend(&head,45);
	display(head);
	
	printf("enter the position want to remove");
	scanf("%d",&pos);
	
	addatfront(&head,89);
	display(head);
	
	removefront(&head);
	display(head);
	
	//removeatpos(&head,pos);
	//display(head);
	return 0;
}


  
