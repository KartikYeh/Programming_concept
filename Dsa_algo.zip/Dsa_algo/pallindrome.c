#include<stdio.h>

struct pald
{
	int size;
	int arr[200];
	int top;
	
};

void init(struct pald *p)
{
	(*p).size=5;
	(*p).top=-1;
}

int isempty(struct pald *p)
{
	if((*p).top==-1)
	{
		return 1;
	}
	else
		return 0;
	
}
int isfull(struct pald *p)
{
	if((*p).top==(*p).size-1)
	{
		return 1;
	}
	else
		return 0;
}
void push(struct pald *p,int val)
{       
     	if(!isfull(p))
	{
		(*p).top++;
		(*p).arr[(*p).top]=val;
	
	}
		
	else
		printf("stack is full");
}
int pop(struct pald *p)
{
	int temp=-1;
	if(!isempty(p)) 
	{
		temp=((*p).arr[(*p).top]);
		
			(*p).top--;
		}
	else 
		printf("stack is empty");
		return temp;
}


int main()
{
	struct pald p1,p2;
	init(&p1);
	init(&p2);
	
	int n,rev,num;
	printf("Enter the number to check");
	scanf("%d",&n);
	num=n;
	
	while(num>0)
	{
		int temp;
		temp=num%10;
		push(&p1,temp);
		num/=10;
	}
	while(!isempty(&p1))
	{
		push(&p2,pop(&p1));
	}
	rev=0;
	while(!isempty(&p2))
	{
		int t=pop(&p2);
		rev=rev*10+t;
	}
	
	if(n==rev)
	{
		printf("Given number is pallindrome");
	}
	else
	{
		printf("Number is not Pallindrome");
	}
	



	return 0;
}



























