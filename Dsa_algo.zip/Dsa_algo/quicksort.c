#include<stdio.h>

int partition(int *arr,int lower,int upper)
{
	int i,j,pivot,temp;
	pivot=arr[upper];
	i=lower-1;
	j=lower;
	
	while(j<upper)
	{
		if(arr[j]<pivot)
		{
			i =i+1;
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
		j++;
	
	}
	temp=arr[upper];
	arr[upper]=arr[i+1];
	arr[i+1]=temp;
	return i+1;


}

void quicksort(int *arr,int lower,int upper)
{
	int q;
	
	if(lower<upper)
	{
		q=partition(arr,lower,upper);
		quicksort(arr,lower,q-1);
		quicksort(arr,q+1,upper);
		
		
	}

}






int main()
{	
	int arr[100],n,i;
	printf("how many integers\n");
	scanf("%d",&n);
	
	printf("enter thye integers");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	
	}
	
	quicksort(arr,0,n-1);
	for(int i=0;i<n;i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
	
	
	
	return 0;
}
