#include<stdio.h>


int LinearSearch(int *arr,int n,int val)
{
	int i;
	for(i=0;i<n;i++)
	{
		if(val==arr[i])
		{
			return i;
		}
	}
	return -1;
	
}

int main()
{
	int arr[100],n,i,val,index;
	
	printf("How many integers?\n");
	scanf("%d",&n);
	
	
	printf("Enter integers:\n");
	for(i=0;i<n;i++)
	{
	
	scanf("%d",&arr[i]);
	}
	
	
	printf("Enter the element to be searched:");
	scanf("%d",&val);
	
	index= LinearSearch(arr,n,val);
	
	if(index!=1)
	{
		printf("Element found at index %d ",index);
		
	}
	else
	{
		printf("EWlement Not found\n");
	}


return 0;
}

