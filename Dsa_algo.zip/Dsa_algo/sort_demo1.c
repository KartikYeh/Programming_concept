#include<stdio.h>

insetionsort(int *arr, int n)
{
	int i,j,key;
	for(i=1;i<n;i++)
	{
		key=arr[i];
		for(j=i-1;j>=0;j--)
		{	
			key=arr[i];
			if(arr[j]>key)
				arr[j+1]=arr[j];			
	                else
	         		break; 
	  	}
	                 arr[j+1]=key;
	             
	     
	}
}


int main()
{	
	int arr[100],n,i;
	printf("how many integers");
	scanf("%d",&n);
	
	printf("enter thye integers");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	
	}
	
	insetionsort(arr, n);
	for(int i=0;i<n;i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
	
	
	
	return 0;
}
