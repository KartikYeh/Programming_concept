#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct node 
{
	int data;
	struct node *next;	
};
void addatend(struct node **phead,int val)
{
	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	
	if((*phead)==NULL)
	{
		*phead=temp;
	}
	else
	{
		trav=*phead;
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=temp;
		
	}
}
void removefromend(struct node **phead)
{
	struct node *trav=*phead;
	struct node *follow=trav;
	while(trav->next!=NULL)
	{
		follow=trav;
		trav=trav->next;
	}
	follow->next=NULL;
	free(trav);
}

void removefrombegin(struct node **phead)
{
	struct node *t=*phead;
	(*phead)=(*phead)->next;
	free(t);
}

void removefrompos(struct node **phead,int pos)
{
	struct node *trav=*phead;
	struct node *follow=trav;
	while(pos>1)
	{
		follow=trav;
		trav=trav->next;
		pos--;
	}
	follow->next=trav->next;
	free(trav);

}

void display(struct node *head)
{
	struct node *trav=head;
	while(trav!=NULL)
	{
		printf("%d ",trav->data);
		trav=trav->next;
	}
	printf("\n");

}


int main()

{
	struct node *head=NULL;
	
	addatend(&head,11);
	addatend(&head,12);
	addatend(&head,3);
	addatend(&head,15);
	addatend(&head,20);
	
	display(head);
	
	removefrombegin(&head);
	display(head);
	
	
	removefromend(&head);
	display(head);
	
	removefrompos(&head,3);
	display(head);

	return 0;
}












