#include<stdio.h>

struct cqueue
{
	int size;
	int arr[10];
	int rear ,front;
		
};
void Init(struct cqueue *cq)
{
	cq->size=5;
	cq->rear=cq->front=cq->size-1;

}
void Insert(struct cqueue *cq,int val)
{
	if(!isfull(cq))
	{
		cq->rear=(cq->rear+1)%cq->size;
		cq->arr[cq->rear]=val;
		
	}else
		printf("circular queue is full /n");
}
int Remove(struct  cqueue *cq)
{
	int temp=-1;
	if(!isempty(cq))
	{
		cq->front=(cq->front+1)%cq->size;
		temp=cq->arr[cq->front];
		
	}else 
		printf("circular queue is empty\n");
	

}
int isfull(struct cqueue *cq)
{
	if (cq->front==(cq->rear+1)%cq->size)
		return 1;
	else
		return 0;
}
int isempty(struct cqueue *cq)
{
	if(cq->front==cq->rear)
		return 1;
	return 0;

}
int main()
{	struct cqueue q1;
	Init(&q1);
	Insert(&q1,10);
	Insert(&q1,15);
	Insert(&q1,20);
	Insert(&q1,25);
	//Insert(&q1,30);
	
	printf("%d ",Remove(&q1));
	printf("%d ",Remove(&q1));
	printf("%d ",Remove(&q1));
	printf("%d ",Remove(&q1));
	//printf("%d",Remove(&q1));
	
	

	return 0;
}

































