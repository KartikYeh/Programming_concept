#include <stdio.h>
#include <stdlib.h>

struct node
{
	int data;
	struct node *left,*right;
};

void insert (struct node **proot, int val)
{
	struct node *trav;
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	
	temp->data=val;
	temp->left=temp->right=NULL;
	
	if((*proot)==NULL)
	{
		*proot=temp;
	}
	
	else
	{
		trav=*proot;
		while(1)
		{
			if(trav->data>temp->data)
			{
				if(trav->left==NULL)
				{
					trav->left=temp;
					break;
				}
				else
					trav=trav->left;
			}
			else if(trav->data<temp->data)
			{
				if( trav->right==NULL)
				{
					trav->right=temp;
					break;
				}
				else
					trav=trav->right;
				
			}else
				break;
		}
	
	}
	
}

void inorder(struct node *trav)//lnr
{
	if(trav!=NULL)
	{
		inorder(trav->left);
		printf("%d ",trav->data);
		inorder(trav->right);
	}
}
void preorder(struct node *trav)//nlr
{
	if(trav!=NULL)
	{	
		printf("%d ",trav->data);//print
		inorder(trav->right);//right move
		inorder(trav->left);//left move
		
	}
}
void postorder(struct node *trav)//lrn
{
	if(trav!=NULL)
	{
		inorder(trav->left);
		inorder(trav->right);
		printf("%d ",trav->data);
	}
}


void Remove(struct node **proot,int data)
{
	struct node *t = *proot, *p = *proot;
	struct node *trav= *proot;
	struct node *tr;
	
	while(1)
	{
		if(trav->data==data)
		{
			t=trav;
			break;
		}
		else if(trav->data>data)
		{
			p=trav;
			trav=trav->left;
		}
		else if(trav->data<data)
		{
			p=trav;
			trav=trav->right;
		}
	}
	
	if(t->left !=NULL && t->right !=NULL)
	{
		tr=t;
		p=t;
		t=t->right;
		while(t->left!=NULL)
		{
			p=t;
			t=t->left;
		}
		tr->data=t->data;
	}
	if(t->left==NULL && t->right==NULL)
	{
		if(p->left==t)
		{
			p->left=NULL;
		}
		else if(p->right==t)
		{
			p->right=NULL;
		}
	else if(t->left!=NULL && t->right ==NULL)
		{
			if(p->left==t)
			{
				p->left=t->left;
			}
			else if(p->right==t)
			{
				p->right=t->left;
			}
		}
	else if(t->left==NULL &&t->right!=NULL)
		{
			if(p->left==t)
			{
				p->left=t->right;
			}
			else if(p->right==t)
			{
				p->right=t->right;
			}
		}
	}
	free(t);
}






int main()
{
	struct node  *root=NULL;
	
	insert(&root,50);
	insert(&root,24);
	insert(&root,30);
	insert(&root,13);
	insert(&root,23);
	
	printf("inorder\n");
	inorder(root);
	printf("\n");
	
	printf("preorder\n");
	preorder(root);
	printf("\n");
	
	printf("postorder\n");
	postorder(root);
	printf("\n");
	
	
	
	printf("remove\n");
	Remove(&root,50);
	
	inorder(root);
	printf("\n");
	
	
	return 0;
}
