//write a program  to convert decimal to binary


#include<stdio.h>
struct stack
{
	int size;
	int arr[10];
	int top;
};
void Init(struct stack *s)
{
	(*s).size=50;
	(*s).top=-1;
}

int isfull(struct stack *s)
{
	if ((*s).top==(*s).size-1)
	
	
		return 1;
	else
		return 0;
	
	
}
int isempty(struct stack *s)
{
	if ((*s).top==-1)
	
		return 1;
	else
		return 0;
	
}


void push( struct stack *s, int val)
{
	if(!isfull(s))
	{
		(*s).top++;
		(*s).arr[(*s).top]=val;
	
	}
		
	else
		printf("stack is full");
	
}
	
	
int pop(struct stack *s)
{
	int temp=-1;
	if(!isempty(s)) 
	{
		temp=((*s).arr[(*s).top]);
		
			(*s).top--;
		}
	else 
		printf("stack is empty");
		return temp;
	
	



}	
	
	
 
int main()
{
	struct stack s1;
	int num;
	
	
	
	Init(&s1);
	printf("Enter the ekement ");
	scanf("%d",&num);
	
	while(num>0)
	{
		push(&s1,num%2);
		num=num/2;
	}
	while(!isempty(&s1))
	{
		printf("%d",pop(&s1));
	}
	printf("\n");
	
	
	return 0;
}






































