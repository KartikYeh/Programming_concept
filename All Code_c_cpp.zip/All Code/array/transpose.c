#include<stdio.h>

void Accept(int m[3][3])
  {
    printf("enter the values:\n");
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        scanf("%d",&m[i][j]);
      }
    }
  }
  void multiply(int m1[3][3],int m2[3][3],int result[3][3])
  {
    
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
        { for(int k=0;k<3;k++)
          {
        result[i][j]+= m1[i][k]*m2[k][j];
          }
        }
    }
  }
  
void Display(int m[3][3])
  {
  
   
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        printf("%d ",m[i][j]);
        
      }printf("\n");
    }
  }
  void accepttranspose(int result[3][3])
  {
  
   
    for(int i=3;i>0;i++)
    {
      for(int j=3;j>0;j++){
        scanf("%d",&result);
    }
  }
  void displaytranspose(int result[3][3], int trans[3][3])
  {
  
   
    for(int i=3;i>0;i++)
    {
      for(int j=3;j>0;j++){
    

    }
  }


int main(){
  int m1[3][3];
  int m2[3][3];
  int result[3][3];
  int transpose[3][3];
  
  Accept(m1);
  Accept(m2);
 multiply(m1,m2,result);
  
  printf("matrics1:\n");
  Display(m1);
  
  printf("matrics2:\n");
  Display(m2);
  
  printf("mul of matrics1 and matrics2 is:\n");
  Display(result);
  
  printf("transpose of result:\n");
  Displaytranspose( result,transpose);
  return 0;
}
