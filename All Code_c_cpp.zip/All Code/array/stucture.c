#include<stdio.h>
#include<stdlib.h>

typedef struct Laptop{
  int srno;
  char make[20];
  double cost;
}lappy;
int main()
{
  typedef int abc;
  abc a=10;
  printf("%d\n",a);
  lappy l={101,"Lenovo",4500},l2;
  lappy l3,*lptr;
  printf("%d%s%lf",l1.srno,l1.make,l1.cost);
  
  printf("Enter laptop details(id,make,cost)\n");
  scanf("%d %s %lf",&l2.srno,&l2.make,&l2.cost);
  scanf("srno:%d make:%s cost:%lf",l2.srno,l2.make,l2.cost);
  
  iptr=(struct Laptop*)malloc(sizeof(struct Laptop));
  printf("Enter laptop details(id,make,cost)\n");
  scanf("%d %s %lf",&l2->srno,&l2->make,&l2->cost);
  scanf("srno:%d make:%s cost:%lf",l2->srno,l2->make,l2->cost);
  
  







  return 0;
}
