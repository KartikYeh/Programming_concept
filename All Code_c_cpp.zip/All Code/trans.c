#include<stdio.h>
int main()
{	int trans[3][3], m[3][3];

  printf("enter the values:\n");
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        scanf("%d",&m[i][j]);
      }
    }
    
     for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        printf("%d ",m[i][j]);
        
      }printf("\n");
    }
    printf("enter the values:\n");
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        trans[j][i]=m[i][j];
      }
    }
     printf("trans values:\n");
  for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        printf("%d ",trans[i][j]);
        
      }printf("\n");
    }

  return 0;
  }
