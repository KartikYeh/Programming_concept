#include<stdio.h>
void swap(int* a,int* b, int ex)
  {
    *a=*b;
    *b=ex;
    ex=*a;
    printf("value of a = %d value of b=%d\n");
  }

int main()

  
  {  int a=4,b=5;
    int ex;
    printf("number = %d\n");
    swap(*a,*b,ex);
  }
