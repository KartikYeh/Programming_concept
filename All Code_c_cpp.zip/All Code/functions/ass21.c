#include <stdio.h>

void areaperi(int radius,float *parea,float *pperi){

  *pperi=3.142*radius*radius;
  *parea=2*3.142*radius;

}
void periarea(int len,int brd,float *rarea,float *rperi){
  *rarea=len*brd;
  *rperi=2*(len+brd);
}
int main(){
  int choice,radius,len,brd;
  float peri,area,rarea,rperi;
  printf("1.circle\n.2.rectangle\n");
  printf("enter the choice:\n");
  scanf("%d",&choice);
  switch(choice){
  case 1:
  printf("enter radius:\n");
  scanf("%d",&radius);
  areaperi(radius,&area,&peri);
  printf("area of circle is %f and perimeter of circle is:%f",area,peri);
  break;
  
  case 2:
  printf("enter len and brd:\n");
  scanf("%d%d",&len,&brd);
  periarea(len, brd,&rarea,&rperi);
  printf("area of rectangle is:%f and perimeter of rectangle is:%f\n",rarea,rperi);
  break;
  }

  return 0;
}
