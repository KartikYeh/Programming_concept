#include<stdio.h>


int main()
{
  int m1,m2,m3,m4,m5;
  float avg;
  printf("Enter marks in five subjects:\n");
  scanf("%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5);
  
  //avg=(m1+m2+m3+m4+m5)/5.0f; //implicit type conversion
  avg=(float)(m1+m2+m3+m4+m5)/5; //explicit type conversion
 printf("avg=%f",avg);




  return 0 ;
}
