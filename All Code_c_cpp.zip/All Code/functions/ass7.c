#include<stdio.h>

int main(){
  int year;
  printf("Enter the year:");
  scanf("%d",&year);
  //by 
  



}
