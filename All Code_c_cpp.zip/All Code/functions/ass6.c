#include<stdio.h>

int main(){
  char ch;
  printf("enter the character:");
  scanf("%c",&ch);
  
  printf("%d",ch);
  return 0;
}
