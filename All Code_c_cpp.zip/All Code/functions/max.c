#include<stdio.h>


int max(int a,int b,int *m){
  if(a>b){
  *m=a;
  }else if(a<b){
  *m=b;
  }else{
  printf("invalid input");
  }

}

int main(){
  int a,b,m;
  printf("enter the two nums:\n");
  scanf("%d %d",&a,&b);
  
  max(a,b,&m);
  printf("the max num is %d",m);

  
  return 0;
}
