#include <stdio.h>

int main(){
  int bs;
  float hra,da,pf,gs,ns;
  printf("Enter basic salary");
  scanf("%d",&bs);
  
  hra=0.15f*bs;
  da=0.3f*bs;
  
  gs=bs+hra+da;
  pf=0.125*gs;
  
  ns=gs - pf;
  printf("Gross salary=%f\n nNet Salary=%f\n",gs,ns);
  




  return 0;
}
