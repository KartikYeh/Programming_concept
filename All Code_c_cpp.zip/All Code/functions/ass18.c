#include<stdio.h>
void charline(int len,char ch){
  int i;
  for(i=1;i<len;i++){
    printf("%c",ch);
   
  } printf("\n");
}

int main(){
  int len;
  char ch;
  printf("Enter the length of border:\n");
  scanf("%d",&len);
  getchar();
  printf("Enter character:\n");
  scanf("%c",&ch);
  
  charline(len,ch);
  printf("data type \t\t size\n");
  charline(len,ch);
  printf("integer \t\t 4\n");
  charline(len,ch);
  printf("character \t\t 1\n");
  charline(len,ch);
  printf("float    \t\t 4\n");
  
  
  return 0;
}
