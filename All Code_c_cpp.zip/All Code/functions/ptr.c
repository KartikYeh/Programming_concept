#include<stdio.h>
void areacircum(float radius,float *area,float *circumference){
  *area=3.14 * radius * radius;
  *circumference=2 * 3.14 * radius;
}
void areaperi(int length,int breath,float *rarea,float *rperimeter){
  *rarea=length*breath;
  *rperimeter=2*(length+breath);


}

int main(){
  int choice;
  printf("select 1.circle 2.rectangle");
  scanf("%d",&choice);
  
  switch(choice){
  case 1:
  float radius,area,circumference;
    printf("Enter the radius of circle:");
    scanf("%f",&radius);
    
    areacircum( radius,&area,&circumference);
    printf("area of the circle: %f\n",area);
    printf("circumference of the circle: %f\n",circumference);
    break;
  
  
  case 2:
  float length, breath,rarea,rperimeter;
  printf("enter length and breath:");
  scanf("%f %f",&length,&breath);
    areaperi( length, breath,&rarea,&rperimeter);
    printf("the area of rectangle is:%f\n",rarea);
    printf("the perimeter of rectangle is:%f\n",rperimeter);
  break;
  
  
  default: 
  printf("enter correct choice");
  break;
  
  }
  
  return 0;
}
