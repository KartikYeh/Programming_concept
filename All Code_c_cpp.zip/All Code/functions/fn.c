#include<stdio.h>
void swap(int *pa,int *pb){
  int temp;
  temp=*pa;
  *pa=*pb;
  *pb=temp;

}
int main(){ 
  int a,b;
  printf("Enter the a and b \n");
  scanf("%d %d",&a,&b);
  swap(&a,&b);
  printf("swapped values are %d %d\n",a,b);
  return 0;
}
