#include<stdio.h>
#include<stdlib.h>

typedef struct Laptop{
  int srno;
  char make[20];
  double cost;
}lappy;
int main()
{
  typedef int abc;
  abc a=10;
  printf("%d\n",a);
  lappy l1={101,"Lenovo",4500},l2;
  lappy *lptr;
  printf("%d%s%lf",l1.srno,l1.make,l1.cost);
  
  printf("Enter laptop details(id,make,cost)\n");
  scanf("%d %s %lf",&l2.srno,&l2.make,&l2.cost);
  printf("srno:%d make:%s cost:%lf",l2.srno,l2.make,l2.cost);
  
  lptr=(struct Laptop*)malloc(sizeof(struct Laptop));
  printf("Enter laptop details(id,make,cost)\n");
  scanf("%d %s %lf",&lptr->srno,&lptr->make,&lptr->cost);
  printf("srno:%d make:%s cost:%lf",lptr->srno,lptr->make,lptr->cost);
  
  







  return 0;
}
