#include<stdio.h>
#include<stdlib.h>

int main(){
  int *p,n,i;
  printf("how many inters:\n");
  scanf("%d",&n);
  
  printf("enter the values:\n");
  p=(int*)malloc(sizeof(int)*n);
  
 for(i=0;i<n;i++)
  {
    scanf("%d",&p[i]);
    }printf("Enter array:\n");
 
 for(i=0;i<n;i++)
  {
    printf("%d",p[i]);
  }
  free(p);
  p=NULL;
  printf("\n");
    
    
    
    



  return 0;
}
