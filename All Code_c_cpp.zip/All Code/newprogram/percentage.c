#include <stdio.h>

int main(){
  float percentage;
  printf("enter the percentage:\n");
  scanf("%f",&percentage);
  
  if(percentage>=65){
  printf("first class with distinction\n");
  }
  else if(percentage>=60 && percentage<65){
  printf("first class\n");
  
  }
  else if(percentage>=50 && percentage<60){
  printf("second class\n");
  }
  
  else if(percentage>=40 && percentage<50){
  printf("pass class\n");
  }
  
  else{
  printf("fail\n");
  }
  
  
  
  
  
  return 0;
  }

