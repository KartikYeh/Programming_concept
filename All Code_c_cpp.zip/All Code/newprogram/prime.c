#include<stdio.h>

int main(){
    int n;
    printf("Enter the number:\n");
    scanf("%d",&n);
    
    
    for(int i=2;i<=n;i++){
    
    if(n%i ==0){
    
    printf("It is Not prime");
    break;
    
    }
    else{
    
    printf("Not prime");
    break;
    }
    
    
    }

  
  
  
  
  
  
  
  
  
  
  return 0;
}
