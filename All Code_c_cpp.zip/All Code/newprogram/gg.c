#include<stdio.h>


int main(){
  int user,computer,matchsticks=21;
  
  while(1){
  printf("enter matchsticks left:%d",matchsticks);
  printf("choice matchsticks between 1,2,3,4:");
  scanf("%d",&user);
  }
  
  for(user>=4 || user<=1){
  continue;}
  matchsticks-=user;
  printf("enter matchsticks left:%d",matchsticks);
  computer=5-user;
  matchsticks-=computer;
  printf("enter the matchsticks left:%d",matchsticks);
  
  if(matchsticks==1){
  printf("you lost the game");
  break;
  
  }
  
  


return 0;
}
