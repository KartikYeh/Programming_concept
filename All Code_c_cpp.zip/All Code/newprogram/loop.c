#include <stdio.h>
//program of printing table of user entered number
int main(){
  
  int i=1,num;
  printf("enter number:\n");
  scanf("%d",&num);
  while(i<=10){
  printf("%d ",i*num);
  i++;
  }
  printf("\n");
  
  
  //program of printing table in reverse order

  for(i=10; i>=1; i--){
  printf("%d ",i*num);
  }
  printf("\n");
  
  
  int x;
  do{
  
  printf("Enter positive number:\n");
  scanf("%d",&x);
  
  }while(x<0);


  return 0;
}


