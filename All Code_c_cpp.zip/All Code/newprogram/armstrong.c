#include<stdio.h>

int main(){
  
  int n,reminder,result=0,ogn;
  
  printf("Enter Three Digit Number:");
  scanf("%d",&n);
  ogn=n;
  
  
  while(n>0)
  {
  reminder=n%10;
  result=result+(reminder*reminder*reminder);
  n/=10;
  
  
  
  }
  
  
  if(ogn==result){
  
  printf("It is Armstrong number");
  
  }else{
  
  printf("Not Armstrong number");
  }
  
  
  
  
  
  
  
  
  
  return 0;
}
