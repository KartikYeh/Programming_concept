#include <stdio.h>

int main(){
  
  int choice=3;
  switch(choice)
  {
  
   case 1:
      printf("one\n");
      break;
   case 2:
      printf("two\n");
      break;
   case 3:
      printf("three\n");
      break;
   case 4:
      printf("four\n");
      break;
   default:
      printf("invalid choice");
      break;
  }

  return 0;
}
