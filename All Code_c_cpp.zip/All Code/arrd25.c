#include<stdio.h>
 void removeelement(int *arr,int *n){
  int pos;
  printf("enter position element to be remove:\n");
  scanf("%d",&pos);
  for(int i=pos;i<*n;i++)
    arr[i]=arr[i+1];
    (*n)--;
 }
  void addelement(int *arr,int *n){
  int pos,val;
   printf("enter the value want to add:\n");
   scanf("%d",&val);
   printf("enter position element to be add:\n");
   scanf("%d",&pos);
 
   for(int i=*n;i>pos;i--)
  
    arr[i]=arr[i-1];
    arr[pos]=val;
    (*n)++;
 
 }
 void printarray(int *arr,int n){
 
  for(int i=0;i<n;i++){
    printf("%d",arr[i]);
    printf("\n");
  }
 
 }
int main(){
  int arr[100],n,i;
  printf("How many element:\n");
  scanf("%d",&n);
   printf("Enter array element:\n");
   for(i=0;i<n;i++){
    scanf("%d",&arr[i]);
   }
   removeelement(arr,&n);
   printarray(arr,n);
   addelement(arr,&n);
   printarray(arr,n);
  return 0;
}
