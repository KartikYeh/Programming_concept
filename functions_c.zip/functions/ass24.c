#include<stdio.h>
int findmaxmin(int arr,int n,int i)
    {
      int max,min,i,n;
      max=arr[0];
      
      for(i=1;i<n;i++)
       {
       if(max>arr[i])
        max=arr[i];
       }
       printf("max value of array is ;: %d ",max);
       
       min=arr[0];
       for(i=1;i<n;i++)
        { 
          if(min>arr[i])
          min=arr[i];
        }
       printf("min : %d",min);
    }

void main()
{
 int arr[100],n,i;
  printf("Enter the required value of array \n");
  scanf("%d",&n);
  for(i=0;i<n;i++)
    {
      scanf("%d",&arr[i]);
    }
    printf("element of array : \n");
    
    findmaxmin(arr,n,i);
    
  return 0;
}
