#include <stdio.h>

int *max(int *a,int *b){
  if(*a>*b){
    return a;
  }
  else if(*b>*a){
    return b;
  }
  else{
    return NULL;
  }
  
}

int main(){
  int a,b;
  printf("enter the value a:\n");
  scanf("%d",&a);
  printf("enter the value b");
  scanf("%d",&b);
  
  
  int* p= max(&a,&b);
  printf("the address of max is %u and the value is%d\n ",p,*p);
  



  return 0;
}
