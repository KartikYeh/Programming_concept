#include<stdio.h>


void getdate(int *pday, int *pmonth,int *pyear){
  printf("enter the day,month,year:\n");
  scanf("%d%d%d",pday,pmonth,pyear);

}

int main(){
  int day,month,year;
  getdate(&day, &month,&year);
  
  printf("%d/%d/%d",day,month,year);
  return 0;
}
