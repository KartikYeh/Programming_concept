#include<stdio.h>

*\void Findmin(int arr[],int n){
  int min,i;
  min=arr[0];
  for(i=1;i<n;i++){
    if(arr[i]<min)
    min=arr[i];
        
  }printf("the min no is:%d\n",min);\*
  
  
  
  
  
  //void Findmax(int arr[],int n){
  int max,min,i;
  max=arr[0];
  for(i=1;i<n;i++){
    if(arr[i]>max)
    max=arr[i];
        
  }printf("the max no is:%d\n",max);
  min=arr[0];
  for(i=1; i<n; i++){
      if(arr[i]<min)
          min=arr[i];
  }printf("Min value : %d\n", min);

}
int main()
{
  int arr[100],n,i;
  printf("enter the size of array\n");
  scanf("%d",&n);
  printf("enter the n integers:\n");
  for(i=0;i<n;i++)
  scanf("%d",&arr[i]);
  Findmax(arr,n);
 

