#include<stdio.h>
int main()
{
int i=1,num;
printf("enter a number \n");
scanf("%d",&num);
  while(i<=10)
  {
  printf("%d\n",num*i);
  i++;
  }
  printf("While loop end here \n");
  for(i=1;i<=10;i++)
  {
    printf("%d\n",i*num );
  }
  printf("for loop end here\n");
  do
  {printf("\n");
  scanf("%d",&num);
    printf("%d\n",i*num);
    printf("\n");
    i=i+1;
  }while(i<=10);
return 0;


}
