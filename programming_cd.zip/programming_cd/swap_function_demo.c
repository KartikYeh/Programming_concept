#include<stdio.h>
void swap(int a,int b)
{
  int temp;
  temp=a;
  a=b;
  b=temp;
  printf("swapped values are %d and %d\n", a, b);
}
int main()
{
 swap(3,4);
}
