#include<stdio.h>
int main()
{
  int n;
  printf("enter number");
  scanf("%d",&n);
  
  for(int i=2; i<=n; i++){
  
  
  if(n%i == 0){
  
  printf("not prime");
  break;
  }else{printf("prime");
  break;}
  
  
  
  }
  
  return 0;
}
