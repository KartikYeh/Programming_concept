#include <stdio.h>
int main(){
  int num, a, b ,c , sum; 
  printf("Enter the four digit number\n");
  scanf("%4d", &num);
  a=num%10;
  num= num/10;
  b=num%10;
  num= num/10;
  c=num%10;
  num= num/10;
  sum=a+b+c+num;
  printf("sum of digits = %d\n", sum);
  return 0;
}
