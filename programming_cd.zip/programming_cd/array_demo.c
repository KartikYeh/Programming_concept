#include<stdio.h>
int main()
{
  int arr[5]={10,20,30,40,50};
  printf("%lu\n",arr);
}
