#include<stdio.h>
int main ()
{
  int arr[10], n,j;
  printf("Enter the range of array \n");
  scanf("%d", &n);
  printf("Enter elements of array\n");
  for(int i=0; i<n ; i++)
  {
   scanf("%d",&arr[i]);
  }
  printf("Enter the position of array you want to delete \n");
  scanf("%d", &j);
  printf("Element you want to delete is %d\n", arr[j]);
  for(j ; j<n ; j++)
  {
    arr[j]=arr[j+1];
  }
  printf("new modified array is :\n");
  for(int k=0; k<(n-1); k++)
  {
    printf("%d\n",arr[k]);
  }
  
}
