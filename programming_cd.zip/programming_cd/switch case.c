#include <stdio.h>
int main()
{
int choice;
printf(" enter your choice \n");
scanf(" %d",&choice);
switch (choice)
{
  case 1: 
  printf("\n your choice is one ");
  break;
  
  case 2:
  printf("\nyour choice is two");
  break;
  
  case 3:
  printf(" \n your choice is three ");
  break;
  
  case 4:
  printf("\n your choice is four");
  break;
  
  default:
  printf("invalid choice");
  


}



}
