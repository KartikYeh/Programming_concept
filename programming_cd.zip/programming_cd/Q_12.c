#include<stdio.h>
int main()
{
  int num,a,b,c,arm,d;
  printf("Enter number : \n");
  scanf("%d",&num);
  d=num;
  a=num%10;
  num=num/10;
  printf("%d\n",a);
  b=num%10;
    num=num/10;
  c=num%10;
   num=num/10;
  arm=(a*a*a)+(b*b*b)+(c*c*c);
  printf("%d\n",arm);
  if (d==arm)
  {
   printf("given number is armstrong number \n");

  }
  else
  {
  printf("Ordinary number \n");
  }
}
