#include <stdio.h>
int max(int a,int b)

{  
  if (a>b)
  {
  printf("a is greater than b \n");
  }
  else
  {
  printf("b is greater than a \n");
  }

}
int main ()
{
int a,b ;
printf("enter two numbers \n ");
scanf("%d%d",&a,&b);
max(a,b);


}
