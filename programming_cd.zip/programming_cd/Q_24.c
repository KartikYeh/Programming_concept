#include<stdio.h>
void maxmin(int arr[5])
{ int a ;
  int ab[5];
  ab[0]=arr[0];
  ab[1]=arr[1];
  ab[2]=arr[2];
  ab[3]=arr[3];
  ab[4]=arr[4];
  for(int i=1; i<5; i++)
  {
    if(arr[0]<arr[i])
    {
       arr[0]=arr[i];
    }
  }
   printf("Maximum number is %d\n", arr[0]);
    for(int i=1; i>5; i++)
  {
    if(ab[i]<ab[0])
    {
       ab[0]=ab[i];
    }
  }
 
  printf("Minimum number is %d\n", ab[0]);
}
int main()
{
   int arr[5];
   printf("enter elements of array \n");
   for(int i=0; i<5; i++)
   {
    scanf("%d", &arr[i]);
   }
   maxmin(arr);
   
   return 0;

}
