#include<stdio.h>
int main()
{
  int i=12;
  const int *p=&i;
  p++ //valid 
  (*p)++; //invalid 
  int * const q= &i ;
  q++; //invalid 
  (*q)++; // valid 
  const int* const r= &i;
  r++;//invalid 
  (*r)++ //invalid 
  return 0;
}
