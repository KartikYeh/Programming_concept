#include<stdio.h>
void areaPeri()
{
  float l,w,area , peri;
  printf("Enter length and breadth of rectangle \n");
  scanf("%f %f", &l, &w);
  area= l*w;
  peri= 2*(l+w);
  printf("Area of rectangle is %f\n", area );
  printf("Perimeter of rectangle is %f\n", peri);
}
void AreaCircum()
{
  float r,area,circ;
  printf("Enter radius of circle :\n");
  scanf("%f",&r);
  area = 3.14*r*r;
  circ= 2*3.14*r;
  printf("Area of circle is %f\n", area);
  printf("Circumference of circle is %f\n", circ);
}
int main()
{
  int c;
  printf("Enter your choice 1 for circle and 2 for rectangle \n.");
  scanf("%d",&c);
  if(c==1)
  {
    AreaCircum(); 
  }
  else
  {
    areaPeri();
  }
  return 0;
}



