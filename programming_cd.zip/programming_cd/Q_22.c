#include<stdio.h>
void getDate()
{ int dd,mm,y;
  printf("Enter a date\n  ");
  scanf("%2d%2d%4d",&dd,&mm,&y);

  printf("%2d/%2d/%4d",dd,mm,y);
}

int main()
{
 getDate();

return 0;

}
