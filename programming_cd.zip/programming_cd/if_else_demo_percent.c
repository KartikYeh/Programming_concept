#include<stdio.h>
int main()
{
  float percent;
  printf("Enter your percentage\n ");
  scanf("%f", &percent);
  if(percent>=65)
  {
  printf("First class with distinction\n");
  
  }
  else if(percent>=60 && percent< 65)
  {
    printf("First class \n");
    
  }
  else if (percent >= 50 && percent <60)
  {
    printf("Second Class\n");
  }
  else if (percent<50 && percent>=40)
  {
    printf("Pass Class \n");
    
  }
  else
  {
    printf("Fail\n");
  }
  return 0;
}
