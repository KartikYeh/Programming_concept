#include<stdio.h>
int main(){
  int i=0;
  do{
    printf("%d\n",i);
    i++;
  }while(i<=10);
}
