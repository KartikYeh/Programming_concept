#include <stdio.h>
int main()
{
int a;
char b;
 printf("size of = %ld",sizeof(a));
 printf("size of b =%d ", sizeof(b) );
 return 0;


}
